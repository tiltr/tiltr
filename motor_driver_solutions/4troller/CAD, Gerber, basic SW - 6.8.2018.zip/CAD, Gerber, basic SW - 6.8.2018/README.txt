--------------------------------------------------------------
6.8.2018
-DXF files for laser or water jet cutting
-PCB gerber files
-Some basic SW (This is functional SW, but it's just a basic HW test)
-Some photos
-I will update this files, when I had some more time
--------------------------------------------------------------